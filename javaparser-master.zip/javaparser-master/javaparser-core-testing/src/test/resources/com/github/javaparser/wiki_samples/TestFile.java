package com.github.javaparser.wiki_samples;

public class TestFile {
    public void foo(int e) {
        int a = 20;
    }

    public void abc() {

    }

    public int def() {
        return 10;
    }
}
