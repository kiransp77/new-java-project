package com.github.javaparser;

public class TestFile {

    public String str�ng = "Strange attribute name [check the i]";

}
