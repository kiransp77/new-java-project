package com.github.javaparser.range;

public class B {
    public void foo() {
        int b = 42;
    }
}
