package com.github.javaparser.ast.validator;

/**
 * This validator validates according to Java 14 syntax rules.
 */
public class Java14Validator extends Java13Validator {

    public Java14Validator() {
        super();
    }
}
