package com.github.javaparser.ast.validator;

/**
 * This validator validates according to Java 6 syntax rules.
 */
public class Java6Validator extends Java5Validator{
    public Java6Validator() {
        super();
    }
}
